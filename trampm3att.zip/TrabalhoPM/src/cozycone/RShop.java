package cozycone;

import java.util.ArrayList;
import java.util.List;

import cone.Ramen;

public class RShop {
	public static double BALANCO_FINAL = 0.00;
	public static final int MAX_CLIENTES = 10;
	private static RShop instancia;
	private List<Ramen> listaRamen;
	private List<Observer> observers = new ArrayList<Observer>();

	private RShop() {
		this.listaRamen = new ArrayList<Ramen>();
	}

	public static synchronized RShop GetInstance() {
		if (instancia == null) {
			instancia = new RShop();
		}
		return instancia;
	}

	public void checkIn(Cliente cliente, Ramen ramen) {
		if (listaRamen.size() < MAX_CLIENTES)
			listaRamen.add(ramen);
		else
			cliente.setRShop(this);
	}

	public double checkout(Ramen ramen, double checkout) {
		listaRamen.remove(ramen);
		double preco = ramen.getPreco(checkout);
		BALANCO_FINAL = BALANCO_FINAL + ramen.getPreco(checkout);
		notifyAllObservers();
		return preco;
	}

	public void attach(Observer observer) {
		observers.add(observer);
	}
	

	public void notifyAllObservers() {
		for (Observer observer : observers) {
			observer.update();
		}
		this.observers = new ArrayList<Observer>();
	}
}
