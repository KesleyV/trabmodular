package cozycone;

public class Cliente extends Observer {

	@Override
	public void update() {
		System.out.println("Notifica��o recebida");
	}

	public void setRShop(RShop rshop) {
		this.rshop = rshop;
		this.rshop.attach(this);
	}
}
