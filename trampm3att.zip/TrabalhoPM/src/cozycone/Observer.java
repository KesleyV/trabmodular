package cozycone;

public abstract class Observer {
	protected RShop rshop;

	public abstract void update();

}