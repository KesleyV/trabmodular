package cozycone;

import cone.Ramen;
import cone.RamenGrande;
import cone.RamenPequeno;
import cone.RamenMedio;
import servico.FabricaDeServico;
import servico.TipoServico;

public class Aplicacao {

	public static void main(String[] args) {

		double checkout = 0.00;

		FabricaDeServico fabricaDeServicos = new FabricaDeServico();

		Cliente Joao = new Cliente();
		Cliente Jose = new Cliente();
		Cliente Junior = new Cliente();

		Ramen ramen1 = new RamenGrande();
		ramen1.tipoRamen(1);
		System.out.println(ramen1.getPreco(checkout));
		ramen1 = fabricaDeServicos.getServico(TipoServico.CARNEEXTRA, ramen1);
		System.out.println(ramen1.getPreco(checkout));
		ramen1 = fabricaDeServicos.getServico(TipoServico.CHAVERDE, ramen1);
		System.out.println(ramen1.getPreco(checkout));

		Ramen ramen2 = new RamenMedio();
		ramen1.tipoRamen(2);
		ramen1 = fabricaDeServicos.getServico(TipoServico.SHITAKE, ramen1);
		ramen1 = fabricaDeServicos.getServico(TipoServico.REFRIGERANTE, ramen1);


		Ramen ramen3 = new RamenPequeno();
		ramen3.tipoRamen(3);
		ramen3 = fabricaDeServicos.getServico(TipoServico.TOFU, ramen3);
		ramen3 = fabricaDeServicos.getServico(TipoServico.CHAPRETO, ramen3);

		RShop rshop = RShop.GetInstance();
		rshop.checkIn(Joao, ramen1);
		rshop.checkIn(Jose, ramen2);
		rshop.checkIn(Junior, ramen3);

		System.out.println("Total do pedido 1: " + ramen1.getPreco(checkout));
		System.out.println("Total do pedido 2: " + ramen2.getPreco(checkout));
		System.out.println("Total do pedido 3: " + ramen3.getPreco(checkout));
		
		System.out.println("Pedido 1 finalizado: " + rshop.checkout(ramen1, checkout));
		System.out.println("O balan�o final �: " + rshop.BALANCO_FINAL);
		System.out.println("Pedido 2 finalizado: " + rshop.checkout(ramen2, checkout));
		System.out.println("O balan�o final �: " + rshop.BALANCO_FINAL);
		System.out.println("Pedido 3 finalizado: " + rshop.checkout(ramen3, checkout));
		System.out.println("O balan�o final �: " + rshop.BALANCO_FINAL);
		
		

	}

}
