package servico;

import cone.Ramen;

public class FabricaDeServico {
	public Ramen getServico(TipoServico tipoServico, Ramen ramen) {
		if (tipoServico == null) {
			return null;
		}
		if (tipoServico.equals(TipoServico.CARNEEXTRA)) {
			return new CarneExtra(ramen);
		} else if (tipoServico.equals(TipoServico.CHILLI)) {
			return new Chilli(ramen);
		} else if (tipoServico.equals(TipoServico.CREMEDEALHO)) {
			return new CremedeAlho(ramen);
		} else if (tipoServico.equals(TipoServico.CROUTONS)) {
			return new Croutons(ramen);
		} else if (tipoServico.equals(TipoServico.SHITAKE)) {
			return new Shitake(ramen);
		} else if (tipoServico.equals(TipoServico.TOFU)) {
			return new Tofu(ramen);
		} else if (tipoServico.equals(TipoServico.CHAVERDE)) {
			return new ChaVerde(ramen);
		} else if (tipoServico.equals(TipoServico.REFRIGERANTE)) {
			return new Refrigerante(ramen);
		} else if (tipoServico.equals(TipoServico.CHAPRETO)) {
			return new ChaPreto(ramen);
		}

		return null;
	}
}
