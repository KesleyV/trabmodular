package servico;


import cone.Ramen;

public abstract class ServicoDecorator implements Ramen {

	@Override
	public double getPreco(double checkout) {
		return 0;
	}

}
