package servico;

import cone.Ramen;

	public class Croutons extends ServicoDecorator {

		private final Ramen ramen;
		private static final double PRECO = 2;

		public Croutons(Ramen ramen) {
			this.ramen = ramen;
		}

		@Override
		public double getPreco(double checkout) {
			return ramen.getPreco(checkout) + PRECO;
		}

		public Ramen getRamen() {
			return ramen;
		}
		
		@Override
		public void tipoRamen(int i) {
			
		}
	}


