package servico;


import cone.Ramen;

public class CremedeAlho extends ServicoDecorator {

	private final Ramen ramen;
	private static final double PRECO = 1.50;
	
	

	public CremedeAlho(Ramen ramen) {
		this.ramen = ramen;
	}
	
	@Override
	public double getPreco(double checkout) {
		return ramen.getPreco(checkout) + PRECO;
	}


	public Ramen getRamen() {
		return ramen;
	}
	
	@Override
	public void tipoRamen(int i) {
		
	}

}
