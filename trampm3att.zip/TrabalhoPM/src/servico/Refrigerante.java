package servico;

import cone.Ramen;

public class Refrigerante extends ServicoDecorator {

	private final Ramen ramen;
	private static final double PRECO = 5.90;

	public Refrigerante(Ramen ramen) {
		this.ramen = ramen;
	}

	@Override
	public double getPreco(double checkout) {
		return ramen.getPreco(checkout) + PRECO;
	}

	public Ramen getCone() {
		return ramen;
	}
	
	@Override
	public void tipoRamen(int i) {
		
	}

}
