package servico;

import cone.Ramen;

public class ChaVerde extends ServicoDecorator {

	private final Ramen ramen;
	private static final double PRECO = 3.90;

	public ChaVerde(Ramen ramen) {
		this.ramen = ramen;
	}

	@Override
	public double getPreco(double checkout) {
		return ramen.getPreco(checkout) + PRECO;
	}

	public Ramen getCone() {
		return ramen;
	}
	
	@Override
	public void tipoRamen(int i) {
		
	}


}
