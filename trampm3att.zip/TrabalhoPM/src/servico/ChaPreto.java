package servico;

import cone.Ramen;

public class ChaPreto extends ServicoDecorator {

	private final Ramen ramen;
	private static final double PRECO = 0.00;

	public ChaPreto(Ramen ramen) {
		this.ramen = ramen;
	}

	@Override
	public double getPreco(double checkout) {
		return ramen.getPreco(checkout) + PRECO;
	}

	public Ramen getCone() {
		return ramen;
	}
	
	@Override
	public void tipoRamen(int i) {
		
	}

}
