package servico;

import cone.Ramen;

public class CarneExtra extends ServicoDecorator {

	private final Ramen ramen;
	private static final double PRECO = 4;

	public CarneExtra(Ramen ramen) {
		this.ramen = ramen;
	}

	@Override
	public double getPreco(double checkout) {
		return ramen.getPreco(checkout) + PRECO;
	}

	public Ramen getRamen() {
		return ramen;
	}

	@Override
	public void tipoRamen(int i) {
		
	}
}
