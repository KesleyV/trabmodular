package servico;

import cone.Ramen;

public class Chilli extends ServicoDecorator {

	private final Ramen ramen;
	private static final double PRECO = 2.50;

	public Chilli(Ramen ramen) {
		this.ramen = ramen;
	}

	@Override
	public double getPreco(double checkout) {
		return ramen.getPreco(checkout) + PRECO;
	}

	public Ramen getCone() {
		return ramen;
	}

	@Override
	public void tipoRamen(int i) {
		
	}
}
