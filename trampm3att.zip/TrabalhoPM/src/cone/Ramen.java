package cone;


public interface Ramen {

	public double getPreco(double checkout);

	public void tipoRamen(int i);
	
}
