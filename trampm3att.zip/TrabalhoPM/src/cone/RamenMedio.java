package cone;


public class RamenMedio implements Ramen {
	private static final double PRECO = 12.90;
	private static final double vegano = 3.90;
	private static final double porco = 5.90;
	private static final double boi = 7.90;
	private double tiporamen;

	public RamenMedio() {
	}


	@Override
	public double getPreco(double Checkout) {
		return Checkout = PRECO + tiporamen;
	}
	@Override
	public void tipoRamen(int tiporamen) {
		if (tiporamen == 1) {
			 this.tiporamen = vegano;
		}
		else if (tiporamen == 2) {
			this.tiporamen = porco;
			}
		else if (tiporamen == 3) {
			this.tiporamen = boi;	
			}
	}

}
